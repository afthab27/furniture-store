export class Country {
    id: number;
    code: string;
    name: string;
}
